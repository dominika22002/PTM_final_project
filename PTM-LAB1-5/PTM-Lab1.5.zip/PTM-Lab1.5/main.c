#include <avr/io.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <stdio.h>
#include <util/delay.h>
#include <avr/sfr_defs.h>
#include <math.h>
#include <avr/interrupt.h>
#include <avr/eeprom.h>
#include <avr/iom32.h>
#include "HD44780.h"

#ifndef _BV
#define _BV(bit) (1 << (bit))
#endif

#ifndef inb
#define inb(addr) (addr)
#endif

#ifndef outb
#define outb(addr, data) addr = (data)
#endif

#ifndef sbi
#define sbi(reg, bit) reg |= (_BV(bit))
#endif

#ifndef cbi
#define cbi(reg, bit) reg &= ~(_BV(bit))
#endif

#ifndef tbi
#define tbi(reg, bit) reg ^= (_BV(bit))
#endif

// MIN/MAX/ABS macros
#define MIN(a, b) ((a < b) ? (a) : (b))
#define MAX(a, b) ((a > b) ? (a) : (b))
#define ABS(x) ((x > 0) ? (x) : (-x))

char *hello = "Program PTM 2021";
char *index = "252871 252839";

void first_run_of_program(bool first_run)
{
	if (first_run)
	{
		LCD_GoTo(0, 0);
		LCD_WriteText(hello);
		LCD_GoTo(0, 1);
		LCD_WriteText(index);
		_delay_ms(4000);
		first_run = false;
		LCD_Clear();
	}
}

int main()
{
	LCD_Initalize();
	LCD_Home();
	LCD_Clear();
	bool first_run = true;

	while (1)
	{
		first_run_of_program(first_run);

	}
}
